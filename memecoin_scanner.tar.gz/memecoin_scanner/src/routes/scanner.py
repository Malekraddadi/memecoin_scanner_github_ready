from flask import Blueprint, jsonify, request
import requests
import time
from datetime import datetime
from flask_cors import cross_origin

scanner_bp = Blueprint('scanner', __name__)

# API Endpoints
DEXSCREENER_API_BASE = "https://api.dexscreener.com"

# Exchange Fees (estimated)
EXCHANGE_FEES = {
    "raydium": {"buy": 0.0025, "sell": 0.0025},
    "orca": {"buy": 0.003, "sell": 0.003},
    "sushiswap": {"buy": 0.003, "sell": 0.003},
    "pumpportal": {"buy": 0.005, "sell": 0.005},
}

def fetch_new_tokens(chain_id="solana", limit=50):
    """Fetch newly created tokens from DEX Screener."""
    try:
        # Get trending tokens first
        trending_url = f"{DEXSCREENER_API_BASE}/latest/dex/tokens/trending"
        trending_response = requests.get(trending_url, timeout=10)
        
        new_tokens = []
        
        if trending_response.status_code == 200:
            trending_data = trending_response.json()
            if trending_data and trending_data.get("pairs"):
                new_tokens.extend(trending_data["pairs"][:20])
        
        # Also get some search results for Solana tokens
        search_url = f"{DEXSCREENER_API_BASE}/latest/dex/search"
        search_params = {"q": "solana"}
        search_response = requests.get(search_url, params=search_params, timeout=10)
        
        if search_response.status_code == 200:
            search_data = search_response.json()
            if search_data and search_data.get("pairs"):
                # Add unique pairs that aren't already in new_tokens
                existing_addresses = {token.get("pairAddress") for token in new_tokens}
                for pair in search_data["pairs"][:30]:
                    if pair.get("pairAddress") not in existing_addresses:
                        new_tokens.append(pair)
                        if len(new_tokens) >= limit:
                            break
        
        return new_tokens[:limit]
        
    except requests.exceptions.RequestException as e:
        print(f"Error fetching new tokens: {e}")
        return []

def analyze_token_potential(pair_data):
    """Analyze a token's potential based on various metrics."""
    if not pair_data:
        return {"score": 0, "reasons": ["No data available"]}
    
    score = 0
    reasons = []
    
    # Check liquidity (higher is better, but not too high to avoid established tokens)
    liquidity_usd = pair_data.get("liquidity", {}).get("usd", 0)
    if 5000 <= liquidity_usd <= 100000:
        score += 25
        reasons.append("Optimal liquidity range for growth potential")
    elif 1000 <= liquidity_usd < 5000:
        score += 15
        reasons.append("Low but sufficient liquidity")
    elif liquidity_usd < 1000:
        score += 5
        reasons.append("Very low liquidity - high risk/reward")
    
    # Check market cap (lower is better for early stage)
    market_cap = pair_data.get("marketCap")
    if market_cap:
        if market_cap < 50000:
            score += 30
            reasons.append("Very low market cap - early stage gem potential")
        elif market_cap < 250000:
            score += 20
            reasons.append("Low market cap - good growth potential")
        elif market_cap < 1000000:
            score += 10
            reasons.append("Medium market cap - moderate potential")
    
    # Check age (newer tokens get higher scores)
    created_at = pair_data.get("pairCreatedAt")
    if created_at:
        creation_time = datetime.fromtimestamp(created_at / 1000)
        age_hours = (datetime.now() - creation_time).total_seconds() / 3600
        if age_hours < 6:
            score += 35
            reasons.append("Extremely new token (< 6 hours)")
        elif age_hours < 24:
            score += 25
            reasons.append("Very new token (< 24 hours)")
        elif age_hours < 72:  # 3 days
            score += 15
            reasons.append("New token (< 3 days)")
        elif age_hours < 168:  # 1 week
            score += 10
            reasons.append("Recent token (< 1 week)")
    
    # Check transaction activity and momentum
    txns = pair_data.get("txns", {})
    recent_txns = txns.get("h24", {})
    if recent_txns:
        buys = recent_txns.get("buys", 0)
        sells = recent_txns.get("sells", 0)
        total_txns = buys + sells
        
        if total_txns > 100:
            score += 20
            reasons.append("High transaction activity")
        elif total_txns > 50:
            score += 15
            reasons.append("Good transaction activity")
        elif total_txns > 20:
            score += 10
            reasons.append("Moderate transaction activity")
        
        # Buy/sell ratio analysis
        if buys > 0 and sells > 0:
            buy_ratio = buys / (buys + sells)
            if buy_ratio > 0.6:
                score += 20
                reasons.append("Strong buying pressure")
            elif buy_ratio > 0.5:
                score += 10
                reasons.append("Balanced buying activity")
    
    # Check price momentum
    price_change = pair_data.get("priceChange", {})
    h24_change = price_change.get("h24")
    h6_change = price_change.get("h6")
    h1_change = price_change.get("h1")
    
    if h24_change and h24_change > 50:
        score += 25
        reasons.append("Strong 24h price momentum (+50%+)")
    elif h24_change and h24_change > 20:
        score += 15
        reasons.append("Good 24h price momentum (+20%+)")
    elif h24_change and h24_change > 0:
        score += 10
        reasons.append("Positive 24h price movement")
    
    if h6_change and h6_change > 20:
        score += 15
        reasons.append("Strong recent momentum (6h)")
    
    if h1_change and h1_change > 10:
        score += 10
        reasons.append("Very recent pump detected (1h)")
    
    # Volume analysis
    volume = pair_data.get("volume", {})
    h24_volume = volume.get("h24", 0)
    if h24_volume > 50000:
        score += 20
        reasons.append("High trading volume")
    elif h24_volume > 10000:
        score += 15
        reasons.append("Good trading volume")
    elif h24_volume > 1000:
        score += 10
        reasons.append("Moderate trading volume")
    
    # Check for potential red flags and adjust score
    if market_cap and market_cap > 10000000:  # 10M+ market cap
        score -= 20
        reasons.append("⚠️ High market cap - limited upside potential")
    
    if liquidity_usd > 500000:  # Very high liquidity might indicate established token
        score -= 15
        reasons.append("⚠️ Very high liquidity - may be established")
    
    # Bonus for meme-like characteristics
    token_name = pair_data.get("baseToken", {}).get("name", "").lower()
    token_symbol = pair_data.get("baseToken", {}).get("symbol", "").lower()
    
    meme_keywords = ["doge", "pepe", "shib", "moon", "rocket", "inu", "cat", "frog", "meme", "chad", "wojak"]
    if any(keyword in token_name or keyword in token_symbol for keyword in meme_keywords):
        score += 15
        reasons.append("🎭 Meme-themed token detected")
    
    return {"score": min(score, 100), "reasons": reasons}  # Cap score at 100

@scanner_bp.route('/scan', methods=['GET'])
@cross_origin()
def scan_memecoins():
    """Scan for potential memecoin opportunities."""
    try:
        # Fetch new tokens
        new_tokens = fetch_new_tokens()
        
        opportunities = []
        for token in new_tokens:
            analysis = analyze_token_potential(token)
            
            # Only include tokens with a decent score (lowered threshold for more results)
            if analysis["score"] >= 25:
                opportunity = {
                    "symbol": token.get("baseToken", {}).get("symbol", "Unknown"),
                    "name": token.get("baseToken", {}).get("name", "Unknown"),
                    "address": token.get("baseToken", {}).get("address", ""),
                    "price_usd": float(token.get("priceUsd", 0)),
                    "market_cap": token.get("marketCap"),
                    "liquidity_usd": token.get("liquidity", {}).get("usd", 0),
                    "age_hours": 0,  # Will calculate if needed
                    "score": analysis["score"],
                    "reasons": analysis["reasons"],
                    "dex": token.get("dexId", "Unknown"),
                    "pair_address": token.get("pairAddress", ""),
                    "url": token.get("url", ""),
                    "timestamp": datetime.now().isoformat()
                }
                
                # Calculate age
                created_at = token.get("pairCreatedAt")
                if created_at:
                    creation_time = datetime.fromtimestamp(created_at / 1000)
                    opportunity["age_hours"] = round((datetime.now() - creation_time).total_seconds() / 3600, 1)
                
                opportunities.append(opportunity)
        
        # Sort by score (highest first)
        opportunities.sort(key=lambda x: x["score"], reverse=True)
        
        return jsonify({
            "success": True,
            "opportunities": opportunities[:10],  # Return top 10
            "total_scanned": len(new_tokens),
            "scan_time": datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "opportunities": [],
            "scan_time": datetime.now().isoformat()
        }), 500

@scanner_bp.route('/token/<token_address>', methods=['GET'])
@cross_origin()
def get_token_details(token_address):
    """Get detailed information about a specific token."""
    try:
        # Fetch token details from DEX Screener
        url = f"{DEXSCREENER_API_BASE}/latest/dex/tokens/{token_address}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        if data and data.get("pairs"):
            pair = data["pairs"][0]  # Get the first pair
            analysis = analyze_token_potential(pair)
            
            token_details = {
                "symbol": pair.get("baseToken", {}).get("symbol", "Unknown"),
                "name": pair.get("baseToken", {}).get("name", "Unknown"),
                "address": token_address,
                "price_usd": float(pair.get("priceUsd", 0)),
                "market_cap": pair.get("marketCap"),
                "liquidity_usd": pair.get("liquidity", {}).get("usd", 0),
                "volume_24h": pair.get("volume", {}).get("h24", 0),
                "price_change_24h": pair.get("priceChange", {}).get("h24", 0),
                "transactions_24h": pair.get("txns", {}).get("h24", {}),
                "score": analysis["score"],
                "reasons": analysis["reasons"],
                "dex": pair.get("dexId", "Unknown"),
                "pair_address": pair.get("pairAddress", ""),
                "url": pair.get("url", ""),
                "timestamp": datetime.now().isoformat()
            }
            
            return jsonify({
                "success": True,
                "token": token_details
            })
        else:
            return jsonify({
                "success": False,
                "error": "Token not found"
            }), 404
            
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@scanner_bp.route('/health', methods=['GET'])
@cross_origin()
def health_check():
    """Health check endpoint."""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "service": "memecoin_scanner"
    })

